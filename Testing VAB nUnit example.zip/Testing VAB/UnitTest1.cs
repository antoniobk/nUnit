using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Threading;
namespace TestProject;

public class Tests
{        

    IWebDriver driver = new ChromeDriver();


    [SetUp]
    public void Setup()
    {
     
    }

    [Test]
    public void LoginMicrosoftFO()
    {
       
            driver.Url = "https://vab-apo-d365fo-tst01c4b0a58cacc80b05devaos.axcloud.dynamics.com/?cmp=vab&mi=DefaultDashboard";
            driver.Manage().Window.Maximize();
            Thread.Sleep(3000);
            driver.FindElement(By.Id("i0116")).SendKeys("abz@vab.be");
            Thread.Sleep(3000);
            driver.FindElement(By.Id("idSIButton9")).Click();
            Thread.Sleep(3000);
            driver.FindElement(By.Id("i0118")).SendKeys("********");
            Thread.Sleep(3000);
            driver.FindElement(By.Id("idSIButton9")).Click(); 
            Thread.Sleep(3000);
            driver.FindElement(By.Id("idSIButton9")).Click();

            string title =  driver.FindElement(By.Id("defaultdashboard_1_WorkItemsList_text")).GetAttribute("InnerHTML");

            if(title == "Work items assigned to me") {
                Assert.Pass();
            }

            else {
                Assert.Fail();
            }
            
    }
}