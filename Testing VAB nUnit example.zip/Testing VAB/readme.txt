Open Visual Studio code
Install NuGet Package Manager extention
Download .NET core sdk
Download C# Extension for Visual Studio Code
Test if dotnet is installed (VSC -> Terminal -> dotnet --version)
Create new Nunit test project (VSC -> Terminal dotnet new nunit)
Restore all depandencies (popup) click restore
Download .NET Core Test Explorer extension
Download Selenium Webdriver extension
Download Chromedriver extension
Go to settings (left under corner) -> serch for Dotnet-test-explorer: set name of nunit test project (.csproj file)
